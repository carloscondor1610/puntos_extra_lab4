
`timescale 1ns / 1ps

module maindec(
    input  [6:0] op,
    output [1:0] ResultSrc,
    output MemWrite,
    output Branch, ALUSrc,
    output RegWrite, Jump, Jalr,
    output [1:0] ImmSrc,
    output [1:0] ALUOp
);

    reg [11:0] controls;

    assign {
        RegWrite,
        ImmSrc,
        ALUSrc,
        MemWrite,
        ResultSrc,
        Branch,
        ALUOp,
        Jump,
        Jalr
    } = controls;

    always @(*) begin
        case(op)
            // RegWrite_ImmSrc_ALUSrc_MemWrite_ResultSrc_Branch_ALUOp_Jump_Jalr

            7'b0000011: controls = 12'b1_00_1_0_01_0_00_0_0; // LW

            7'b0100011: controls = 12'b0_01_1_1_00_0_00_0_0; // SW

            7'b0110011: controls = 12'b1_xx_0_0_00_0_10_0_0; // R-type (ADD, XOR)

            7'b1100011: controls = 12'b0_10_0_0_00_1_01_0_0; // BEQ

            7'b0010011: controls = 12'b1_00_1_0_00_0_10_0_0; // ADDI

            7'b1101111: controls = 12'b1_11_0_0_10_0_00_1_0; // JAL

            7'b1100111: controls = 12'b1_00_1_0_10_0_00_1_1; // JALR

            default: controls = 12'bx_xx_x_x_xx_x_xx_x_x;
        endcase
    end

endmodule
