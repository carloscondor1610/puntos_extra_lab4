`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/16/2026 10:38:00 AM
// Design Name: 
// Module Name: aludec
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module aludec(input  opb5,
              input  [2:0] funct3,
              input  funct7b5, 
              input  [1:0] ALUOp,
              output [2:0] ALUControl);
  
  wire  RtypeSub; 
  reg [2:0] ALUControl_reg; 

  assign RtypeSub = funct7b5 & opb5;  // TRUE for R-type subtract instruction
  assign ALUControl = ALUControl_reg;

  always @* case(ALUOp)
      2'b00:                ALUControl_reg = 3'b000; // addition
      2'b01:                ALUControl_reg = 3'b001; // subtraction
      default: case(funct3) // R-type or I-type ALU
            3'b000: if (RtypeSub)
                        ALUControl_reg = 3'b001; // SUB
                    else
                        ALUControl_reg = 3'b000; // ADD, ADDI

            3'b010: ALUControl_reg = 3'b101; // SLT
            3'b100: ALUControl_reg = 3'b100; // XOR (NUEVO)
            3'b110: ALUControl_reg = 3'b011; // OR
            3'b111: ALUControl_reg = 3'b010; // AND

            default: ALUControl_reg = 3'bxxx;
        endcase
    endcase
endmodule