`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/16/2026 10:43:51 AM
// Design Name: 
// Module Name: regfile
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////

module regfile(
    input clk,
    input we3,
    input [4:0] a1, a2, a3,
    input [31:0] wd3,
    output [31:0] rd1, rd2
);

    reg [31:0] rf[31:0];

    // Escritura en flanco positivo
    always @(posedge clk) begin
        if (we3 && a3 != 5'd0)
            rf[a3] <= wd3;
    end

    // Lectura combinacional
    assign rd1 = (a1 != 5'd0) ? rf[a1] : 32'b0;
    assign rd2 = (a2 != 5'd0) ? rf[a2] : 32'b0;

endmodule