
`timescale 1ns / 1ps

module alu(
    input  [31:0] a, b,
    input  [2:0]  alucontrol,
    output reg [31:0] result,
    output zero
);

    wire [31:0] condinvb;
    wire [31:0] sum;
    wire overflow;

    // Invertir B cuando la operacion requiere resta
    assign condinvb = alucontrol[0] ? ~b : b;

    // Suma o resta mediante complemento a dos
    assign sum = a + condinvb + alucontrol[0];

    // Deteccion de overflow para SLT
    assign overflow =
        (~(a[31] ^ b[31] ^ alucontrol[0])) &
        (a[31] ^ sum[31]);

    // Seleccion de operacion
    always @(*) begin
        case (alucontrol)

            3'b000: result = sum;            // ADD / ADDI / JALR

            3'b001: result = sum;            // SUB

            3'b010: result = a & b;          // AND

            3'b011: result = a | b;          // OR

            3'b100: result = a ^ b;          // XOR

            3'b101: result = sum[31] ^ overflow; // SLT

            3'b110: result = a << b[4:0];   // SLL

            3'b111: result = a >> b[4:0];   // SRL

            default: result = 32'bx;

        endcase
    end

    // Zero = 1 cuando el resultado es cero
    assign zero = (result == 32'b0);

endmodule
