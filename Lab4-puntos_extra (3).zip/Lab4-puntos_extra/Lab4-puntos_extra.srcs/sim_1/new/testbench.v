
`timescale 1ns / 1ps

module testbench;

    reg clk;
    reg reset;

    wire [31:0] WriteData;
    wire [31:0] DataAdr;
    wire MemWrite;

    integer errores;
    integer i;

    reg [31:0] PC_esperado [0:7];

    top dut(
        .clk(clk),
        .reset(reset),
        .WriteData(WriteData),
        .DataAdr(DataAdr),
        .MemWrite(MemWrite)
    );

    // Reloj de 10 ns
    initial clk = 0;
    always #5 clk = ~clk;

    // Reset inicial
    initial begin
        reset = 1;
        #22 reset = 0;
    end

    initial begin
        errores = 0;

        // Direcciones esperadas del programa
        PC_esperado[0] = 32'h00000000;
        PC_esperado[1] = 32'h00000004;
        PC_esperado[2] = 32'h00000008;
        PC_esperado[3] = 32'h0000000C;
        PC_esperado[4] = 32'h00000010;
        PC_esperado[5] = 32'h0000001C;
        PC_esperado[6] = 32'h00000020;
        PC_esperado[7] = 32'h00000024;

        // Esperar a que termine el reset
        @(negedge reset);

        // Verificar las 8 instrucciones ejecutadas
        for (i = 0; i < 8; i = i + 1) begin

            // Verificar antes del flanco positivo
            #1;

            $display(
                "Ciclo %0d | PC = %h | Instr = %h | ALUResult = %h",
                i,
                dut.PC,
                dut.Instr,
                dut.DataAdr
            );

            if (dut.PC !== PC_esperado[i]) begin
                $display(
                    "ERROR PC: esperado=%h obtenido=%h",
                    PC_esperado[i],
                    dut.PC
                );
                errores = errores + 1;
            end
            else begin
                $display("PC CORRECTO: %h", dut.PC);
            end

            // Ninguna instruccion escribe memoria
            if (MemWrite !== 1'b0) begin
                $display("ERROR: MemWrite debe ser 0");
                errores = errores + 1;
            end

            // Ejecutar instruccion y actualizar el PC
            @(posedge clk);
            #1;
        end

        // Verificacion de registros finales
        verificar_registro(1,  32'h00000014);
        verificar_registro(5,  32'h0000000C);
        verificar_registro(6,  32'h0000000A);
        verificar_registro(7,  32'h00000006);
        verificar_registro(10, 32'h00000014);
        verificar_registro(11, 32'h0000000C);
        verificar_registro(12, 32'h00000014);
        verificar_registro(13, 32'h00000018);

        // Resultado final
        if (errores == 0) begin
            $display("------------------------------------");
            $display("EXITO: TODAS LAS PRUEBAS PASARON");
            $display("JALR y XOR funcionan correctamente");
            $display("------------------------------------");
        end
        else begin
            $display("------------------------------------");
            $display("ERROR: %0d PRUEBAS FALLARON", errores);
            $display("------------------------------------");
        end

        $finish;
    end

    // Tarea para comprobar registros
    task verificar_registro;
        input integer numero;
        input [31:0] esperado;
        begin
            if (dut.rvsingle.dp.rf.rf[numero] !== esperado) begin
                $display(
                    "ERROR x%0d: esperado=%h obtenido=%h",
                    numero,
                    esperado,
                    dut.rvsingle.dp.rf.rf[numero]
                );
                errores = errores + 1;
            end
            else begin
                $display(
                    "Registro x%0d CORRECTO: %h",
                    numero,
                    esperado
                );
            end
        end
    endtask

    // Proteccion contra simulaciones infinitas
    initial begin
        #500;
        $display("ERROR: TIEMPO AGOTADO");
        $finish;
    end

endmodule
