`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 10/16/2026 11:43:35 AM
// Design Name: 
// Module Name: testbench_xor
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////



`timescale 1ns / 1ps

module testbench_xor;

    reg clk;
    reg reset;

    wire [31:0] WriteData;
    wire [31:0] DataAdr;
    wire MemWrite;

    // Instanciar el procesador
    top dut(
        .clk(clk),
        .reset(reset),
        .WriteData(WriteData),
        .DataAdr(DataAdr),
        .MemWrite(MemWrite)
    );

    // Inicializar reset
    initial begin
        reset = 1;
        #22;
        reset = 0;
    end

    // Generar reloj de periodo 10 ns
    always begin
        clk = 1;
        #5;
        clk = 0;
        #5;
    end

    // Comprobar resultado XOR
    always @(negedge clk) begin
        if (!reset && MemWrite === 1'b1) begin

            if (DataAdr === 32'd100 &&
                WriteData === 32'd9) begin

                $display("XOR FUNCIONA CORRECTAMENTE");
                $display("Resultado: %d", WriteData);
                $display("Direccion: %d", DataAdr);
                $stop;

            end else begin

                $display("ERROR EN XOR");
                $display("Resultado obtenido: %d", WriteData);
                $display("Direccion obtenida: %d", DataAdr);
                $stop;

            end
        end
    end

    // Evitar simulacion infinita
    initial begin
        #500;
        $display("ERROR: Tiempo de espera agotado");
        $stop;
    end

endmodule

