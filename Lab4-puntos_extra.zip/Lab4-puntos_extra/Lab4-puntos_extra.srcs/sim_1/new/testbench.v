
`timescale 1ns / 1ps

module testbench;

    reg clk;
    reg reset;

    wire [31:0] WriteData;
    wire [31:0] DataAdr;
    wire MemWrite;

    top dut(
        .clk(clk),
        .reset(reset),
        .WriteData(WriteData),
        .DataAdr(DataAdr),
        .MemWrite(MemWrite)
    );

    initial begin
        clk = 0;
        reset = 1;
        #22 reset = 0;
    end

    always #5 clk = ~clk;

    always @(negedge clk) begin
        if (!reset && MemWrite === 1'b1) begin
            if (DataAdr === 32'd96 &&
                WriteData === 32'd7) begin

                $display("Escritura intermedia correcta: mem[96] = 7");

            end else if (DataAdr === 32'd100 &&
                         WriteData === 32'd19) begin

                $display("EXITO: Figura 4 modificada con XOR");
                $display("Memoria[100] = %0d", WriteData);
                $finish;

            end else begin

                $display("ERROR: escritura no esperada");
                $display("Direccion = %0d", DataAdr);
                $display("Dato = %0d", WriteData);
                $finish;
            end
        end
    end

    initial begin
        #500;
        $display("ERROR: tiempo agotado");
        $finish;
    end

endmodule
  